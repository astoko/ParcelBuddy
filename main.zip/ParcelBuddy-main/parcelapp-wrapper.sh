#!/bin/sh
exec python3 /app/main.py
